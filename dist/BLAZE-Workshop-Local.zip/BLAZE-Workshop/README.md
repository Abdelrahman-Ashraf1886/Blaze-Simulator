# BLAZE Workshop

Extract the entire ZIP. Python 3 is the only requirement. The app runs offline and opens in a regular browser.

## Run on one computer

- Windows — double-click `Start-Windows.bat`, or run `py -3 serve.py` in a terminal inside the extracted folder.
- macOS or Linux — open a terminal inside the extracted folder and run `python3 serve.py`.

Open [http://localhost:8000](http://localhost:8000). Keep the terminal open while using the app. Press Ctrl+C to stop it.

## Share with the team on the same network

1. On the host computer, open a terminal inside the extracted folder. Run `py -3 serve.py --lan` on Windows or `python3 serve.py --lan` on macOS or Linux.
2. Share the **On another device** address printed by the server. The address looks like `http://192.168.1.23:8000`. If the host has several network connections, use its IPv4 address on the network shared with the team.
3. Keep the host running. If the operating system prompts you, allow the server on the trusted local network. Teammates who connect to the host only need a browser.

You can also send the ZIP to teammates so they can run their own copy. Append `--port 8080` to use a different port.

The server shares the app files. Builds remain in each browser, and imported STL geometry and placements remain in the current tab session.
