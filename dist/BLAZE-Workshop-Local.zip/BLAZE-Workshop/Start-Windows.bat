@echo off
where py >nul 2>&1
if errorlevel 1 (
    python "%~dp0serve.py" %*
) else (
    py -3 "%~dp0serve.py" %*
)
if errorlevel 1 pause
