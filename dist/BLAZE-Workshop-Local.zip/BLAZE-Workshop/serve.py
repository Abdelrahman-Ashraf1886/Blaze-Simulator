"""Serve BLAZE Workshop on this machine or on its local network."""
import argparse
import socket
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class WorkshopHandler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map,
                      ".mjs": "text/javascript", ".js": "text/javascript"}


def local_address():
    """Find the IP of the default interface without sending a packet."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as connection:
            connection.connect(("192.0.2.1", 9))
            return connection.getsockname()[0]
    except OSError:
        return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lan", action="store_true", help="Allow access from other devices on the local network")
    parser.add_argument("--port", type=int, default=8000, help="HTTP port (default: 8000)")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("--port must be between 1 and 65535")

    host = "0.0.0.0" if args.lan else "127.0.0.1"
    app_dir = Path(__file__).resolve().parent / "app"
    if not (app_dir / "index.html").is_file():
        parser.error("The app folder is missing. Extract the entire ZIP before running the launcher.")

    handler = partial(WorkshopHandler, directory=str(app_dir))
    try:
        with ThreadingHTTPServer((host, args.port), handler) as server:
            print(f"On this computer: http://localhost:{args.port}", flush=True)
            if args.lan:
                address = local_address()
                if address:
                    print(f"On another device: http://{address}:{args.port}", flush=True)
                else:
                    print(f"On another device: use this computer's local IPv4 address and port {args.port}.", flush=True)
            print("Press Ctrl+C to stop.", flush=True)
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
    except OSError as error:
        parser.exit(1, f"Could not start server on port {args.port}: {error}\nTry another port with --port 8080.\n")


if __name__ == "__main__":
    main()
